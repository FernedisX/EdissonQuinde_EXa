package com.fernedisx.app.service;


import com.fernedisx.app.model.Producto;

public interface productoService extends  GenericService<Producto, Integer>{


}
